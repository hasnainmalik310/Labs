#include<iostream>
using namespace std;
int main()
{
	cout<<"\tReturant XYZ\n";
	cout<<"item\tquantity    price\n";
	cout<<"pizza\t2          $15\n";
	cout<<"pasta\t1          $12\n";
	cout<<"soda\t3          $3\n";
	cout<<"total              $51\n";
	return 0;
}
