#include<iostream>
using namespace std;
int main()
{
	cout<<"item\tprice\tquality\n";
	cout<<"pen\t$1\t5\n";
	cout<<"pencil\t$2\t5\n";
	cout<<"eraser\t$0.5\t20\n";
	return 0;
}
