#include<iostream>
using namespace std;
int main()
{
	cout<<"she said, \"lets learn c++!\n";
	cout<<"to start, save your file in c:\\c++_projects\\lab1\n";
	cout<<"good luck!\n";
	return 0;
}
