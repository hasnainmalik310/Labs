#include<iostream>
using namespace std;
int main()
{
	cout<<"Person A: \"hello! how are you?\n";
	cout<<"Person B: \"i am fine, thank you! how about you?\n";
	cout<<"Person B: \"i am doing great. thanks for asking!\n";
	return 0;
}
