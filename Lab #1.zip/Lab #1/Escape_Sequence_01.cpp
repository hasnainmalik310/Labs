#include<iostream>
using namespace std;
int main()
{
	cout<<"welcome to c++ "<<endl;
	cout<<"you will learn basic output today"<<endl;
	cout<<"lets start with simple messages"<<endl;
	return 0;
}
