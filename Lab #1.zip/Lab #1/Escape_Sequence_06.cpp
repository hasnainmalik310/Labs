#include<iostream>
using namespace std;
int main()
{
	cout<<"\t\"The Road Not Taken\"\n";
	cout<<"\tby Robert Frost\n";
	cout<<"Two roads diverged in a yellow wood,\n";
	cout<<"And sorry i could not travel both\n";
	cout<<"And be one taveler, long i started\n";
	cout<<"To where it bent in the undergrowth\n";
	return 0;
}
