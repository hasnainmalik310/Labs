#include<iostream>
using namespace std;
int main()
{
	cout<<"--------------\n";
	cout<<"|\t     |\n";
	cout<<"|  45 + 78   | \n";
	cout<<"| =    123   |\n";
	cout<<"|------------|\n";
	return 0;
}
